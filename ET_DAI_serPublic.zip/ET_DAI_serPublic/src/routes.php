<?php

use Slim\App;
use Slim\Http\Uri;
use Slim\Http\Request;
use Slim\Http\Response;
use Slim\Views\Twig;
use Slim\Http\Environment;
use Slim\Views\TwigExtension;
use Medoo\Medoo;

return function (App $app) {

	//puedes pasar valores por un arreglo
	$app->get('/', function ($request, $response) {
		return $this->view->render($response, 'index.phtml');
	});

	$app->get('/isp', function ($request, $response) {
		return $this->view->render($response, 'publico.html');
	});

	$app->get('/index', function ($request, $response) {
		return $this->view->render($response, 'Indice.html');
	});
	$app->get('/regpart', function ($request, $response) {
		return $this->view->render($response, 'RegistroParticular.html');
	});
	$app->get('/regempr', function ($request, $response) {
		return $this->view->render($response, 'RegistroEmpresa.html');
	});
	$app->get('/elecperfil', function ($request, $response) {
		return $this->view->render($response, 'EleccionPerfil.html');
	});

	$app->post('/agrega', function($request,$response){
		$op=$_POST["guardar"];
		$db = new \Modelo\Contacto($this);

		if ($op=="guarda") {
		
			$db->Agregar($_POST["rut"],$_POST["nombre"],$_POST["contraseña"],$_POST["direccion"],$_POST["nombreC"],$_POST["rutC"],$_POST["telefono"],$_POST["correo"]);
		}
	});

	$app->post('/agregarP', function($request,$response){
		$op=$_POST["registro"];
		$db = new \Modelo\Contacto($this);

		if ($op=="registro") {
		
			$db->AgregarPa($_POST["rut"],$_POST["nombre"],$_POST["contraseña"],$_POST["correo"],$_POST["direccion"]);
		}
	});
};
