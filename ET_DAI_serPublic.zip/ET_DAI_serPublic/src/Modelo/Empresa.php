<?php
namespace Modelo;

/**
 * 
 */
class Empresa
{
	protected $database;

	public function __construct($container)
	{
		$this->database = $container->database;
	}

	public function Dato(){
		$arr = $this->database->select('empresa', ['codEm','rutEm', 'nomEm', 'contraseñaEm', 'direccionEm']);
		return $arr;
	}

	public function Agregar($rutE,$nomE,$conE,$dirE){
		$arr = $this->database->insert('empresa',[
			'rutEm' => 'rutE', 
			'nomEm' => 'nomE', 
			'contraseñaEm' => 'conE', 
			'direccionEm' => 'dirE']
		]);
	}

	public function loggin($rutE,$conE){
		
	}



}