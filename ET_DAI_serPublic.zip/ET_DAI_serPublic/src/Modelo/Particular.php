<?php
namespace Modelo;

/**
 * 
 */
class Particular
{
	protected $database;
	public function __construct($conteiner)
	{
		$this->database = $conteiner->database;
	}

	public function Dato(){
		$arr = $this->database->select('particular', ['codPa', 'rutPa', 'contraseñaPa', 'nomPa', 'direccionPa', 'correoPa']);
		return $arr;
	}

	public function AgregarPa($codP,$rutP,$conP,$nomP,$dirP,$corrP){
		$arr = $this->database->insert('particular', [
			'codPa' => 'cod',
			 'rutPa' => 'rut', 
			 'contraseñaPa' => 'con', 
			 'nomPa' => 'nom', 
			 'direccionPa' => 'dire', 
			 'correoPa' => 'corre'
			]);
	} 

	public function ModificarPa($codP,$rutP,$conP,$nomP,$dirP,$corrP){
		$arr = $this->database->update('particular', [
			'rutPa' => 'rut', 
			'contraseñaPa' => 'con', 
			'nomPa' => 'nom', 
			'direccionPa' => 'dire', 
			'correoPa' => 'corre'],
			['codPa' => $cod
		]);
			return $arr;
		}

}
