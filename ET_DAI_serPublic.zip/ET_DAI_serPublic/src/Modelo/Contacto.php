<?php
namespace Modelo;

/**
 * 
 */
class Contacto extends Empresa
{
	protected $database;
	
	public function __construct($container)
	{
		$this->database = $cointainer->database;
	}

	public function Agregar($rutC,$nomC,$corrC,$telC,$rutE,$nomE,$dirE,$conE){
		parent::Agregar($rutE,$nomE,$conE,$dirE);
		$id = $this->database->max('empresa','codEm');
		$arr = $this->database->insert('empresa',[
			'rutC' => 'rutC', 
			'nomCn' => 'nomC', 
			'correoCn' => 'corrC', 
			'telefonoCn' => 'telC',
			'codEm' => $id
		]);
	}
}